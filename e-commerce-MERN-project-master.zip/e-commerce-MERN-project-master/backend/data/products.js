const products = [
    {
      name: 'Gilet de sauvetage gonflable Marine',
      image: '/images/gilet.jpg',
      description:
        'Nom de marque:	 Baizhou , Couleur :	 La personnalisation acceptéS ',
      brand: 'baizhou',
      category: 'Electronics',
      price: 220.99,
      countInStock: 3,
      rating: 0,
      numReviews: 0,
    },
   
    {
      name: 'Matériel de montage E. galvanisé Marine',
      image: '/images/b.jpg',
      description:
        'type de materiel de montage',
      brand: 'bbbb',
      category: 'Electronics',
      price: 29.99,
      countInStock: 0,
      rating: 0,
      numReviews: 0,
    },
    {
      name: 'Interrupteur ON - OFF -',
      image: 'https://res.cloudinary.com/habibii/image/upload/v1667085360/Interrupteur_ON_-_OFF_-_AUTO_Dim._90_x_50_mm_1_nsvcn9.jpg',
      description:
        'Dim. 90 x 50 mm',
      brand: 'sony',
      category: 'Electronics',
      price: 110.99,
      countInStock: 10,
      rating: 0,
      numReviews: 0,
    },
    {
      name: 'Pompe Tsunami MKII ATTWOOD',
      image: '/images/pompe.jpeg',
      description:
        'tsun',
      brand: 'sony',
      category: 'Electronics',
      price: 100.99,
      countInStock: 7,
      rating: 0,
      numReviews: 0,
    },
    {
      name: 'Turbines',
      image: '/images/tourbine.jpg',
      description:
        'Pièces du turbocompresseur Marine roue de turbine les produits à moulage sous vide',
      brand: 'sony',
      category: 'Electronics',
      price: 33.99,
      countInStock: 0,
      rating: 0,
      numReviews: 0,
    },
  ]
  
  export default products